package Model;

import java.util.UUID;

/**
 *
 * @author AERO
 */
public class User {
    protected UUID idUser;
    protected String nama;
    protected String email;
    protected String password;
    protected String role;

    public User(UUID idUser, String nama, String email, String password, String role) {
        this.idUser = idUser;
        this.nama = nama;
        this.email = email;
        this.password = password;
        this.role = role;
    }
    
    public User(UUID idUser, String email, String password) {
        this.setIdUser(idUser);
        this.setEmail(email);
        this.setPass(password);
    }

    
    public UUID getIdUser() {
        return idUser;
    }

    public void setIdUser(UUID idUser) {
        this.idUser = idUser;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return password;
    }

    public void setPass(String password) {
        this.password = password;
    }
     
}